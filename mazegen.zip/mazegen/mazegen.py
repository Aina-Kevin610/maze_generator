from .parsing import parse_config
from .algo import *
import random

class Maze:
    def __init__(self, filename: str) -> None:
        config = parse_config(filename)
        self.width = int(config["WIDTH"])
        self.height = int(config['HEIGHT'])
        self.entry = config["ENTRY"]
        self.exit = config["EXIT"]
        self.algo = config["ALGO"]
        self.seed = config["SEED"]
        self.rand: random.Random = random.Random()
        if self.seed is not None:
            self.rand = random.Random(self.seed)

    
    def generate(self) -> list[list[int]]:
        if self.algo == 'hunt_and_kill':
            maze = hunt_and_kill([self.width, self.height, self.seed=None])
        return maze




