def init_grid(width: int, height: int) -> tuple[list[bool], list[int]]:
    return (
        [[15 for _ in range(width)] for _ in range(height)],
        [[False for _ in range(width)] for _ in range(height)]
    )


def remove_wall(
        param: list, x: int, y: int, xn: int, yn: int
    ) -> tuple[int, int, int]:
        grid, visited = param
        dx, dy = xn - x, yn - y
        if dx == 1:
            direction = 0b0100
            opposite = 0b0001
        elif dx == -1:
            direction = 0b0001
            opposite = 0b0100
        elif dy == 1:
            direction = 0b0010
            opposite = 0b1000
        elif dy == -1:
            direction = 0b1000
            opposite = 0b0010
        else:
            return xn, yn, 0
        grid[y][x] &= ~direction
        grid[yn][xn] &= ~opposite
        visited[y][x] = True
        visited[yn][xn] = True
        return xn, yn, opposite


def get_neighbors(param, x: int, y: int) -> list[tuple[int, int]]:
    visited, width, height, protected = param
    way = [(0, -1), (1, 0), (0, 1), (-1, 0)]
    neighbors: list[tuple[int, int]] = []
    for dx, dy in way:
        xn, yn = x + dx, y + dy
        if (
            0 <= xn < width
            and 0 <= yn < height
            and not visited[yn][xn]
            and (xn, yn) not in protected
        ):
            neighbors.append((xn, yn))
    return neighbors


def get_visited_neighbors(param, x: int, y: int) -> list[tuple[int, int]]:
    visited, width, height, protected = param
    way = [(0, -1), (1, 0), (0, 1), (-1, 0)]
    neighbors: list[tuple[int, int]] = []
    for dx, dy in way:
        xn, yn = x + dx, y + dy
        if (
            0 <= xn < width
            and 0 <= yn < height
            and visited[yn][xn]
            and (xn, yn) not in protected
        ):
            neighbors.append((xn, yn))
    return neighbors

def make_imperfect(self, rate: float = 0.15) -> None:
    for y in range(self.height):
        for x in range(self.width):
            if (x, y) in self.protected:
                continue
            if x + 1 < self.width and (x + 1, y) not in self.protected:
                if self.rand.random() < rate:
                    self.grid[y][x] &= ~(1 << 2)
                    self.grid[y][x + 1] &= ~(1 << 0)
            if y + 1 < self.height and (x, y + 1) not in self.protected:
                if self.rand.random() < rate:
                    self.grid[y][x] &= ~(1 << 1)
                    self.grid[y + 1][x] &= ~(1 << 3)
