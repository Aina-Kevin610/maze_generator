from .algo_utils import *
phase = ""

def kill(self) -> bool:
    neighbors = get_neighbors(current_x, current_y)
    if not neighbors:
        return False
    xn, yn = rand.choice(neighbors)
    while (xn, yn) in protected:
        xn, yn = rand.choice(neighbors)
    current_x, current_y, wall = remove_wall(
        current_x, current_y, xn, yn
    )
    return True

def hunt(self):
    for i in range(height):
        for j in range(width):
            if (
                not visited[i][j]
                and (j, i) not in protected
            ):
                v_neighbors = get_visited_neighbors(j, i)
                if v_neighbors:
                    xn, yn = rand.choice(v_neighbors)
                    remove_wall(j, i, xn, yn)
                    return j, i
    return None


def step() -> bool:
    if phase == "done":
        return False
    if phase == "kill":
        again = kill()
        if not again:
            phase = "hunt"
        return True
    if phase == "hunt":
        result = hunt()
        if result is None:
            phase = "done"
            if not perfect:
                make_imperfect()
            return False
        current_x, current_y = result
        phase = "kill"
        return True
    return False


def hunt_and_kill([width, height, seed]) -> list[list[str]]:
        if phase == "kill":
            again = kill()
            if not again:
                phase = "hunt"
        elif phase == "hunt":
            result = hunt()
            if result is None:
                phase = "done"
                save(hexa_maze())
            else:
                current_x, current_y = result
                phase = "kill"
    return hexa_maze()
